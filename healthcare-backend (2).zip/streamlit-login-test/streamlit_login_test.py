"""
Login-only Streamlit test page.

Unlike streamlit_app.py, this file imports NOTHING from app.services.* —
it's a pure HTTP client that calls your backend's /v1/auth/login and
/v1/auth/register endpoints. Safe to deploy on Streamlit Community Cloud
without installing langchain / boto3 / faster-whisper / etc.

Your FastAPI backend must be running somewhere reachable (it does NOT run
inside Streamlit Cloud). Point this at it via:
  - a Streamlit secret named API_BASE_URL (Settings -> Secrets on Streamlit
    Cloud), or
  - the API_BASE_URL environment variable when running locally.

Local run:
    pip install -r requirements-auth-test.txt streamlit
    API_BASE_URL=http://localhost:8000 streamlit run streamlit_login_test.py
"""

import os
import streamlit as st
import httpx


def _get_api_url() -> str:
    try:
        if "API_BASE_URL" in st.secrets:
            return st.secrets["API_BASE_URL"]
    except Exception:
        pass
    return os.environ.get("API_BASE_URL", "http://localhost:8000")


API_URL = _get_api_url()
if not API_URL.endswith("/v1"):
    API_URL = f"{API_URL.rstrip('/')}/v1"

st.set_page_config(page_title="Doctor Support — Login Test", layout="centered")

if "token" not in st.session_state:
    st.session_state.token = None
if "user" not in st.session_state:
    st.session_state.user = None


def handle_logout():
    st.session_state.token = None
    st.session_state.user = None
    st.rerun()


st.sidebar.title("Doctor Portal (Login Test)")
st.sidebar.caption(f"API target: {API_URL}")

if not st.session_state.token:
    auth_mode = st.sidebar.radio("Select Mode", ["Login", "Sign Up"])

    if auth_mode == "Login":
        st.sidebar.subheader("Login")
        username = st.sidebar.text_input("Username")
        email = st.sidebar.text_input("Email")
        password = st.sidebar.text_input("Password", type="password")
        if st.sidebar.button("Login"):
            try:
                response = httpx.post(
                    f"{API_URL}/auth/login",
                    json={"username": username, "email": email, "password": password},
                    timeout=10.0,
                )
                if response.status_code == 200:
                    data = response.json()
                    st.session_state.token = data["access_token"]
                    st.session_state.user = data.get("user", {}).get("username", username)
                    st.sidebar.success(f"Welcome, {st.session_state.user}!")
                    st.rerun()
                else:
                    try:
                        detail = response.json().get("detail", response.text)
                    except Exception:
                        detail = response.text
                    st.sidebar.error(f"{response.status_code}: {detail}")
            except Exception as e:
                st.sidebar.error(f"Connection error: {e}")
    else:
        st.sidebar.subheader("Register")
        new_username = st.sidebar.text_input("Username")
        new_email = st.sidebar.text_input("Email")
        new_password = st.sidebar.text_input("Password", type="password")
        new_name = st.sidebar.text_input("Full Name")
        if st.sidebar.button("Register"):
            try:
                response = httpx.post(
                    f"{API_URL}/auth/register",
                    json={
                        "username": new_username,
                        "email": new_email,
                        "password": new_password,
                        "full_name": new_name,
                    },
                    timeout=10.0,
                )
                if response.status_code == 200:
                    data = response.json()
                    st.session_state.token = data["access_token"]
                    st.session_state.user = new_username
                    st.sidebar.success("Account created!")
                    st.rerun()
                else:
                    try:
                        detail = response.json().get("detail", response.text)
                    except Exception:
                        detail = response.text
                    st.sidebar.error(f"{response.status_code}: {detail}")
            except Exception as e:
                st.sidebar.error(f"Connection error: {e}")

    st.title("Login Test — Doctor Support")
    st.info(
        "This is a stripped-down login tester. It only exercises your "
        "backend's /auth endpoints — none of the clinical tooling is "
        "wired up here."
    )
    st.stop()

st.sidebar.write(f"Logged in as **{st.session_state.user}**")
if st.sidebar.button("Logout"):
    handle_logout()

st.title("✅ Login succeeded")
st.write("Token acquired:")
st.code(st.session_state.token[:40] + "...", language=None)
st.success("Auth flow is working end-to-end against your backend.")
